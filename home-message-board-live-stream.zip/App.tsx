import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import BroadcastPage from './pages/BroadcastPage';
import ViewPage from './pages/ViewPage';
import HomePage from './pages/HomePage';
import PasswordPrompt from './components/PasswordPrompt';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(
    () => sessionStorage.getItem('app-authenticated') === 'true'
  );

  const handleSuccess = () => {
    sessionStorage.setItem('app-authenticated', 'true');
    setIsAuthenticated(true);
  };

  if (!isAuthenticated) {
    return <PasswordPrompt onSuccess={handleSuccess} />;
  }

  return (
    <div className="bg-gray-900 text-white min-h-screen font-sans">
      <HashRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/broadcast" element={<BroadcastPage />} />
          <Route path="/view/:sessionId" element={<ViewPage />} />
          <Route path="/view" element={<Navigate to="/" />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </HashRouter>
    </div>
  );
};

export default App;