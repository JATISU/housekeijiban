
import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';

interface QRCodeGeneratorProps {
  url: string;
}

const QRCodeGenerator: React.FC<QRCodeGeneratorProps> = ({ url }) => {
  const [qrCodeUrl, setQrCodeUrl] = useState('');

  useEffect(() => {
    if (url) {
      QRCode.toDataURL(url, {
        width: 256,
        margin: 2,
        color: {
          dark: '#FFFFFF',
          light: '#27272a' // zinc-800
        }
      })
        .then(setQrCodeUrl)
        .catch(err => console.error("QR Code generation failed:", err));
    }
  }, [url]);

  if (!qrCodeUrl) {
    return (
      <div className="w-64 h-64 bg-gray-700 animate-pulse rounded-lg flex items-center justify-center text-gray-400">
        QRコードを生成中...
      </div>
    );
  }

  return (
    <div className="p-4 bg-zinc-800 rounded-lg shadow-lg border border-gray-700">
      <img src={qrCodeUrl} alt="QR Code" width="256" height="256" className="rounded-md" />
    </div>
  );
};

export default QRCodeGenerator;
