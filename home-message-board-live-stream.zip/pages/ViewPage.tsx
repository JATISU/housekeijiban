import React, { useState, useEffect, useRef } from 'react';
import { Link, useParams } from 'react-router-dom';

const WEBSOCKET_URL = 'wss://live-stream-demo-server.glitch.me';

const HomeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
    </svg>
);

const WifiOffIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-yellow-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18.364 5.636a9 9 0 010 12.728m-12.728 0a9 9 0 010-12.728m12.728 0L5.636 18.364M12 12a2 2 0 100-4 2 2 0 000 4z" />
    </svg>
);


type ViewStatus = 'connecting' | 'streaming' | 'disconnected' | 'invalid_session';

const ViewPage: React.FC = () => {
    const { sessionId } = useParams<{ sessionId: string }>();
    const [frameSrc, setFrameSrc] = useState<string | null>(null);
    const [status, setStatus] = useState<ViewStatus>('connecting');
    const staleTimeoutRef = useRef<number | null>(null);

    useEffect(() => {
        if (!sessionId) {
            setStatus('invalid_session');
            return;
        }

        const ws = new WebSocket(WEBSOCKET_URL);

        ws.onopen = () => {
            ws.send(JSON.stringify({ type: 'join', sessionId }));
        };

        ws.onmessage = (event) => {
            try {
                const message = JSON.parse(event.data);
                if (message.type === 'frame' && message.data) {
                    if (status !== 'streaming') {
                        setStatus('streaming');
                    }
                    setFrameSrc(message.data);

                    if (staleTimeoutRef.current) clearTimeout(staleTimeoutRef.current);
                    staleTimeoutRef.current = window.setTimeout(() => {
                        setStatus('disconnected');
                    }, 5000);
                } else if (message.type === 'error' && message.message === 'session_not_found') {
                    setStatus('disconnected');
                }
            } catch (e) {
                console.error('Failed to parse WebSocket message:', e);
            }
        };

        ws.onclose = () => {
            setStatus('disconnected');
        };

        ws.onerror = () => {
            setStatus('disconnected');
        };

        return () => {
            if (staleTimeoutRef.current) clearTimeout(staleTimeoutRef.current);
            ws.close();
        };
    }, [sessionId]);

    if (status === 'invalid_session') {
         return (
             <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
                 <h2 className="text-2xl text-red-500 mb-4">無効なセッション</h2>
                 <p className="text-gray-400 mb-6">配信URLが正しくありません。ホームページに戻ってやり直してください。</p>
                 <Link to="/" className="flex items-center px-6 py-3 bg-cyan-500 hover:bg-cyan-600 rounded-lg transition">
                    <HomeIcon /> ホームへ戻る
                </Link>
             </div>
         )
    }

    return (
        <div className="flex flex-col items-center justify-center min-h-screen p-4">
             <header className="absolute top-0 left-0 right-0 flex justify-between items-center p-4 md:p-6">
                <h1 className="text-2xl md:text-3xl font-bold text-cyan-400">ライブ映像</h1>
                <Link to="/" className="flex items-center px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition">
                    <HomeIcon /> ホームへ
                </Link>
            </header>

            <div className="w-full max-w-4xl aspect-video bg-black rounded-lg shadow-2xl border-2 border-gray-700 overflow-hidden flex items-center justify-center relative">
                {status === 'connecting' && (
                    <div className="text-center">
                        <h2 className="text-2xl text-gray-400 animate-pulse">配信に接続中...</h2>
                        <p className="text-gray-500 mt-2">ストリームが開始されるのを待っています。</p>
                    </div>
                )}
                
                {status === 'streaming' && frameSrc && (
                    <img src={frameSrc} alt="Live Stream" className="w-full h-full object-contain" />
                )}

                {status === 'disconnected' && (
                     <div className="text-center p-8">
                        <WifiOffIcon />
                        <h2 className="text-2xl text-yellow-500 mb-4">配信に接続できません</h2>
                        <p className="text-gray-300 max-w-lg mx-auto">
                            配信が終了したか、現在利用できません。しばらくしてから再度お試しください。
                        </p>
                    </div>
                )}
                
                {status === 'streaming' && (
                     <div className="absolute top-4 left-4 flex items-center text-white px-3 py-1 rounded-full text-sm font-semibold bg-red-600">
                        <span className="w-3 h-3 rounded-full mr-2 bg-white animate-pulse"></span>
                        LIVE
                    </div>
                )}
            </div>
             <p className="mt-4 text-gray-500 text-sm h-5">
                {/* Placeholder for potential future info */}
            </p>
        </div>
    );
};

export default ViewPage;