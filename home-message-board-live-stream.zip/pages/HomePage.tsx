import React from 'react';
import { Link } from 'react-router-dom';

const BroadcastIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
);

const EyeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
);


const HomePage: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center p-4 bg-dots-pattern">
      <div className="bg-gray-900/80 backdrop-blur-sm p-8 rounded-2xl shadow-2xl border border-cyan-500/20">
        <h1 className="text-5xl md:text-6xl font-bold mb-3">
          <span className="text-cyan-400">ライブ</span>掲示板
        </h1>
        <p className="text-lg text-gray-400 mb-10 max-w-md">
          あなたの家の掲示板を、QRコードを使ってどこからでもリアルタイムに。
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link 
            to="/broadcast"
            className="w-full sm:w-auto flex items-center justify-center px-8 py-4 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg shadow-lg transition-transform transform hover:scale-105"
          >
            <BroadcastIcon />
            配信を開始
          </Link>
          <Link 
            to="/view"
            className="w-full sm:w-auto flex items-center justify-center px-8 py-4 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-lg shadow-lg transition-transform transform hover:scale-105"
          >
            <EyeIcon />
            ライブを見る
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;