import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import QRCodeGenerator from '../components/QRCodeGenerator';
import { FRAME_UPDATE_INTERVAL } from '../constants';

const WEBSOCKET_URL = 'wss://live-stream-demo-server.glitch.me';

const HomeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
    </svg>
);

const BroadcastIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
);

const ScreenSharePlaceholderIcon = () => (
     <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
);


const BroadcastPage: React.FC = () => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const intervalRef = useRef<number | null>(null);
    const wsRef = useRef<WebSocket | null>(null);

    const [status, setStatus] = useState<'idle' | 'starting' | 'streaming' | 'error'>('idle');
    const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
    const [error, setError] = useState<string | null>(null);
    const [sessionId] = useState<string>(() => crypto.randomUUID());
    const [viewerUrl, setViewerUrl] = useState('');

    useEffect(() => {
        setViewerUrl(`${window.location.origin}${window.location.pathname}#/view/${sessionId}`);

        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
            if (streamRef.current) {
                streamRef.current.getTracks().forEach(track => track.stop());
                streamRef.current = null;
            }
            wsRef.current?.close();
        };
    }, [sessionId]);

    const handleStartStreaming = async () => {
        if (streamRef.current) return;
        setStatus('starting');
        setError(null);
        setConnectionStatus('connecting');

        try {
            const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
            streamRef.current = stream;

            stream.getVideoTracks()[0].onended = () => {
                 setStatus('idle');
                 if (intervalRef.current) clearInterval(intervalRef.current);
                 streamRef.current = null;
                 wsRef.current?.close();
                 wsRef.current = null;
                 setConnectionStatus('disconnected');
            };

            const ws = new WebSocket(WEBSOCKET_URL);
            wsRef.current = ws;

            ws.onopen = () => {
                setConnectionStatus('connected');
                ws.send(JSON.stringify({ type: 'start', sessionId }));
            };

            ws.onclose = () => {
                if (status !== 'idle') {
                    setStatus('idle');
                }
                setConnectionStatus('disconnected');
            };

            ws.onerror = () => {
                setError('リアルタイムサーバーへの接続に失敗しました。');
                setStatus('error');
                setConnectionStatus('error');
            };


            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                await videoRef.current.play();
            }
            
            setStatus('streaming');

            intervalRef.current = window.setInterval(() => {
                if (videoRef.current && canvasRef.current && videoRef.current.readyState >= 2 && wsRef.current?.readyState === WebSocket.OPEN) {
                    const video = videoRef.current;
                    const canvas = canvasRef.current;
                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                    const ctx = canvas.getContext('2d');
                    if (ctx) {
                        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                        const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
                        wsRef.current.send(JSON.stringify({ type: 'frame', sessionId, data: dataUrl }));
                    }
                }
            }, FRAME_UPDATE_INTERVAL);

        } catch (err) {
            console.error("Screen sharing error:", err);
            setError('画面共有がキャンセルされたか、許可されませんでした。');
            setStatus('error');
            setConnectionStatus('disconnected');
        }
    };

    return (
        <div className="container mx-auto p-4 md:p-8">
            <header className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-cyan-400">配信ページ</h1>
                <Link to="/" className="flex items-center px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition">
                    <HomeIcon /> ホームへ
                </Link>
            </header>

            <div className="flex flex-col lg:flex-row gap-8">
                <div className="flex-grow lg:w-2/3 flex flex-col">
                    <div className="relative aspect-video bg-black rounded-lg shadow-2xl border-2 border-gray-700 overflow-hidden flex items-center justify-center">
                        <video ref={videoRef} muted playsInline className={`w-full h-full object-contain ${status === 'streaming' ? '' : 'hidden'}`}></video>
                        <canvas ref={canvasRef} className="hidden"></canvas>

                        {status === 'streaming' && (
                            <div className="absolute top-4 left-4 flex items-center bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold animate-pulse">
                                <span className="w-3 h-3 bg-white rounded-full mr-2"></span>
                                LIVE
                            </div>
                        )}
                         {status === 'idle' && (
                            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
                                <ScreenSharePlaceholderIcon />
                                <p className="text-xl mt-4 text-gray-300">配信を開始するには、画面共有を開始してください。</p>
                            </div>
                        )}
                        {status === 'starting' && (
                            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                                <p className="text-xl animate-pulse">画面共有を選択中...</p>
                            </div>
                        )}
                        {status === 'error' && (
                            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 p-4 text-center">
                                <h3 className="text-xl text-red-500 font-bold mb-2">エラー</h3>
                                <p className="text-gray-300">{error}</p>
                            </div>
                        )}
                    </div>
                    
                    <div className="h-6 mt-2 text-center text-sm text-gray-400">
                        {status === 'streaming' || status === 'starting' ? (
                            <>
                                {connectionStatus === 'connecting' && 'サーバーに接続中...'}
                                {connectionStatus === 'connected' && '✅ リアルタイムサーバーに接続済み'}
                                {connectionStatus === 'error' && '❌ サーバー接続エラー'}
                                {connectionStatus === 'disconnected' && status === 'streaming' && 'サーバーから切断されました。'}
                            </>
                        ) : ' '}
                    </div>

                    <div className="mt-2 flex justify-center">
                        {(status === 'idle' || status === 'error') && (
                            <button
                                onClick={handleStartStreaming}
                                className="w-full sm:w-auto flex items-center justify-center px-8 py-4 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg shadow-lg transition-transform transform hover:scale-105"
                            >
                                <BroadcastIcon />
                                {status === 'error' ? 'もう一度試す' : '画面共有を開始'}
                            </button>
                        )}
                         {status === 'starting' && (
                            <button
                                disabled
                                className="w-full sm:w-auto flex items-center justify-center px-8 py-4 bg-gray-600 text-white font-bold rounded-lg shadow-lg cursor-not-allowed"
                            >
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                処理中...
                            </button>
                        )}
                    </div>
                </div>

                <div className="flex-shrink-0 lg:w-1/3">
                    <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 h-full flex flex-col items-center justify-center">
                        <h2 className="text-2xl font-semibold mb-2">視聴用QRコード</h2>
                        <p className="text-gray-400 mb-4 text-center">このQRコードをスキャンして、他のデバイスからライブ映像をご覧ください。</p>
                        <QRCodeGenerator url={viewerUrl} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BroadcastPage;